package aesthetics_evaluation_tool;
import java.io.File;
import java.text.DecimalFormat;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class clarity {
	public static float value=0;
	public static int btn1=0;
	public static int item1=0;
	public static int edit1=0;
	
	public static int edit=0;
	public static int nbitem=0;
	public static int nbhint=0;
	public static int nbbutton=0;
	public float clarity() {
		// TODO Auto-generated method stub

		
		
		
		float nbtext=0;
		float nbtitle=0;
		
		main_launcher ML= new main_launcher();
    	String file=main_launcher.Layout_File;
	    try {

	    	
	        File fXmlFile = new File(file);
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory
	                .newInstance();
	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	        Document doc = dBuilder.parse(fXmlFile);
	        doc.getDocumentElement().normalize();

	        
	        if (doc.hasChildNodes()) 
	       
	        {
	        //button calcul
	        NodeList button = doc.getElementsByTagName("Button");
	       
	      
	        for (int temp = 0; temp < button.getLength(); temp++) {
	            
	        	Node nNode = button.item(temp);
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	                Element eElement = (Element) nNode;
	                nbbutton++;
	                if (eElement.hasAttribute("android:text") )
	                	 nbtext++;
	               
	                 // System.out.println("button text: " + eElement.getAttribute("android:text"));
	             
	                    
	                  	            }
	        }
	       
	      //edit text calcul
	        NodeList edittext = doc.getElementsByTagName("EditText");
	       
	      
	        for (int temp = 0; temp < edittext.getLength(); temp++) {
	            
	        	Node nNode = edittext.item(temp);
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	                Element eElement = (Element) nNode;
	                edit++;
	                if (eElement.hasAttribute("android:hint") )
	                	 nbhint++;
	               
	                  // System.out.println("edittext: " + eElement.getAttribute("android:hint"));
	        
	        
	        }
	        
	    }
	        
	    
		  // item calcul
        NodeList typeitem = doc.getElementsByTagName("item");
        for (int temp2 = 0; temp2 < typeitem.getLength(); temp2++) {
        Node nNode2 = typeitem.item(temp2);
        if (nNode2.getNodeType() == Node.ELEMENT_NODE) {
            Element eElement2 = (Element) nNode2;
            nbitem++;
            
            if (eElement2.hasAttribute("android:title") )
            	 nbtitle++;
           
            // System.out.println("item text: " + eElement2.getAttribute("android:title"));
        
        }
        }}
	        }
    
	    
	    
	    
	    
	    
	    
	        catch (Exception e) {
	        e.printStackTrace();
	    }
		
		
		
	 
		btn1=(int) (nbbutton-nbtext);
        item1=(int) (nbitem-nbtitle);
        edit1=edit-nbhint;
       
        
        
       /* System.out.println("text number="+nbtext);	
        System.out.println("title number="+nbtitle);
        System.out.println("editText number="+edit);
        System.out.println("button number="+nbbutton);
        System.out.println("item number="+nbitem);
        System.out.println("hint number="+nbhint);*/
        
        float clarity= (float) ((nbtext+nbtitle+nbhint)/(float)(nbbutton+nbitem+edit));
         value =(float) Double.parseDouble(new DecimalFormat("##.###").format(clarity));
        return Math.abs(value);
       
        
        
        
        
		
		
	}

}
