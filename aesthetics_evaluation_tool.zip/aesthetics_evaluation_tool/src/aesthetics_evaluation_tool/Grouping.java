package aesthetics_evaluation_tool;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Grouping {
public static double value=0;
	public double Grouping() throws IOException {
		// TODO Auto-generated constructor stub
		
		
		
		
		int sizes=economy.occf;
		
		
		int indice_nature=0;
		

				//main_launcher ML= new main_launcher();
		    	String file=main_launcher.data_File;
		    	
		    	InputStream input = new FileInputStream(file);
				 HSSFWorkbook wb     = new HSSFWorkbook(input);
				 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
				 //row number
				 int rowTotal = sheet.getLastRowNum();
			
		      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		          rowTotal++;
		      }
		    	
		      for ( int r=0;r<1; r++){     
					 HSSFRow row     = sheet.getRow(r); 
					 
					 //get cell number in each row
					 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
					 
					 // parse cells values of each row
					 for (int c=0;c<noOfColumns; c++)
			    	        
				        {
						 
					 HSSFCell cell= row.getCell(c);
					// System.out.println("row="+r+"###"+cell.getStringCellValue() );
					 
					 String text= cell.getStringCellValue();
					 //System.out.println("text="+text);
					 if (text.equals("nature"))
					 {
						indice_nature=c; 
						//System.out.println(indice_width);
					 }
					 
				
				        }
					 }
		      
		
		      String[] nature=new String[rowTotal]; 
		      String[] nature_original=new String[rowTotal]; 
				
		      for ( int r=1;r<rowTotal; r++)
		      
		      {   
		    	  HSSFRow row     = sheet.getRow(r); 
		    	  
		    	  //fill the width table
		    	  for (int c=indice_nature;c<indice_nature+1; c++)
		  	        
			        {
		    		  HSSFCell cell= row.getCell(c);
		    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		    		  nature[r-1]= (cell.getStringCellValue());
		    		  nature_original[r-1]= (cell.getStringCellValue());
			        }
		      }
		
	// look for different widgets types
		    	  
		    	  // look for occurrences of width
		          int occnature=0;

		          		for (int i = 0; i < nature.length-1; ++i) { 
		          			String val =nature[i];
		          			int indice=i;
		          			//System.out.println("val"+i+"=="+val);	
		          			
		          			for (int j = i+1; j < nature.length-1; ++j) 
		          			{
		          				if(val.equals(nature[j]))
		          				{
		          					
		          					nature[j]="0";
		          				}
		          				
		          				 if(val.equals("0")) {
		          				        i = indice;
		          				    } 
		          				
		          				
		          			}


		          		}
		          		
		          		
	    					
		          		for (int k = 0; k < nature.length-1; ++k) { 
		          			//System.out.println("outputsizes in width=="+nature[k]);
		          			
		          		}
		          		
		          	
		          		for (int l = 0; l < nature.length-1; ++l) { 
		          			
		          			if(!nature[l].equals("0"))
		          			{
		          				occnature++;
		          			}
		          			
		          		}
		          		
		          		//System.out.println(occnature);
//search for the number of each object type
		          		
		          		//String occ="";
    					int somme=1;
    					int[] types=new int[occnature]; 
		          		
		          			for (int j = 0; j < occnature; ++j) 
		          			{
		          				String val=nature_original[j];
		          				
		          				for (int i =j+1; i < nature_original.length-1; ++i) 
			          			{
		          				if(val.equals(nature_original[i+1]))
		          				{
		          					somme++;
		          					//occ=occ+somme;
		          					nature_original[i+1]="0";
		          					types[j]=somme;
		          				}
		          				else if (!val.equals(nature_original[i+1]))
		          				{
		          					somme=1;
		          				
		          				}
		          				if(val.equals("0"))
		          				{
		          					
		          				}
		          				
			          			}
		          				//occ=occ+",";
		          				
		          			}
	    					//System.out.println(occ);
	    					for (int k = 0; k < occnature; ++k) { 
			          			//System.out.println("outputsizes in width=="+types[k]);
			          			
			          		}
		
		
		
		
		
		
		
		int SumSize=economy.SumSize;
		//System.out.println(SumSize);
		
		double LH=main_launcher.Layoutheight;
		double LW=main_launcher.layoutwidth;
		double FH=main_launcher.Frameheight;
		double FW=main_launcher.Framewidth;
		double UMspace=Math.abs(1-
				( ((double)(LH*LW)/(double)(FH*FW))-(SumSize/(double)(FH*FW)))); 
				
		
		//System.out.println(UMspace);
		
		double Al=0;
		for (int k = 0; k < occnature; ++k) { 
  			
  			Al=Al+Math.abs(   (double)(4*types[k])- (  (double)(regularity.occX*regularity.occY) / (double)(types[k])   ))
  					/  ((double)(4*types[k])-4)  ;
  		}
		
		//System.out.println(Al);
		
		double AL=0;
		if(Al>=1)
		{
		 AL=1;
		}
		else if (Al<1)
		{
			AL=Al;
		}
		
		double grouping= ((UMspace)-(1/(double)(rowTotal-1)))/100;
		//System.out.println(grouping);
		 value =Double.parseDouble(new DecimalFormat("##.###").format(grouping));
		 if (Math.abs(value)>=1)
		 {
		value=1;
		 }
		 
		return Math.abs(value);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
