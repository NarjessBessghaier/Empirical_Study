package aesthetics_evaluation_tool;
import aesthetics_evaluation_tool.regularity;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;


 /* 
 * ADDET - Aesthetics Defects DEtection Tool
 * author BessghaierNarjess
 */

    public class main_launcher {
    	public static final String Name_File="welcome.uixfile.xls";
	// specify the path for the generated file from the emulator
	public static final String data_File = "/Users/bessghaiernarjess/Documents/Ph.D_Thesis/main/tool/DumbFiles/Dump file NewPipe/NewPipe-0.14.2/"+Name_File;
	//specify the path of the related XML layout file of the interface
	public static final String Layout_File = "/Users/bessghaiernarjess/Desktop/default_buttons.xml";
	
	public static final int Framewidth=1080;
	public static final int Frameheight=1920;
	public static final int layoutwidth=1080;
	public static final int Layoutheight=1920;
	public static double nb1=0;
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub

		
		//******CLARITY *******
		clarity CL= new clarity();
		float clarity=CL.clarity();
		int btn= CL.btn1;
		int item= CL.item1;
		int button= CL.nbbutton;
		int items= CL.nbitem;
		int nbedit= CL.edit;
		int nbhint= CL.nbhint;
		int hint=CL.edit1;
		 
		 
		 
		//******ECONOMY ************ 
		economy Eco= new economy();
		float economy=Eco.economy();
		int taille=Eco.taille;
		int occ= Eco.occ;
		
		 
		
		
		//******DENSITY ************ 
		density DN= new density();
		double density=DN.density();
		
		
		
		//******INTEGRALITY ************ 
		integrality InT= new integrality();
		
		double integrality=InT.integrality();
		
		
		//******REGULARITY ************ 
			regularity RG= new regularity();
			double regularity=RG.regularity();
			int distance=RG.distance;
			int distanceX=RG.distanceX;
			int distanceY=RG.distanceY;
			int rows=RG.occX;
			int cols=RG.occY;
			
			 
			 
	   //******SORTING************ 
				Sorting SRT= new Sorting();
				double sorting=SRT.Sorting();
				 
		 
		 
		//******SIMPLICITY ************ 
			simplicity Simp= new simplicity();
			double simplicity=Simp.simplicity();
			
			 
			/*//******LAYOUT COMPLEXITY ************  
			 
			layout_complexity CMP= new layout_complexity(); 
			double complexity=CMP.layout_complexity();
			*/
			
			//******COMPLEXITY ************  
			 
			complexity CMP= new complexity(); 
			double complexity= CMP.complexity();
			
			
			//******LAYOUT-UNIFORMITY ************ 
				Layout_Uniformity LU= new Layout_Uniformity();	
				double uniformity=LU.Layout_Uniformity();
				
				
			//******UNITY ************ 
				unity Un= new unity();	
				double unity=Un.unity();
				int nature=Un.occnature;
				
				//******COHESION ************ 
				Cohesion CH= new Cohesion();	
				
				double cohesion=CH.Cohesion();
				
				
		//******BALANCE ************ 
			balance BL= new balance();
			double balance=BL.balance();
			

		
		//******GROUPING ************ 
			Grouping GRP= new Grouping();
			double grouping=GRP.Grouping();
			
				
			//******REPARTITION ************ 
			repartition REP= new repartition();
			double repartition=REP.repartition();
			
		
			//******NB ELEMENTS ************ 
			nb_elements nb= new nb_elements();
			double elements=nb.nb_elements();
			nb1=elements;
			
			
			//******rules ************ 
			rules r= new rules();
			String[] rule=r.rules();

			
	    // Print the list objects in tabular format.
		 System.out.println("----------------------------------");
		 System.out.printf("%10s", " • METRICS VALUES");
		  System.out.println();
		
		  System.out.println("----------------------------------");
		  System.out.println("-----------------------------------------------------------------------------");
	 System.out.printf("%1s %5s %5s %5s %5s %5s %5s ", "UNIFORMITY", "COMPLEXITY", "SIMPLICITY", "SEQUENCE", "REGULARITY", "INTEGRALITY", "DENSITY");
	 System.out.println();  
	 System.out.println("-----------------------------------------------------------------------------");
	 
	   System.out.format(" %1s %10s %10s %10s %9s %10s %10s ",
               uniformity,  complexity,simplicity, sorting, regularity,integrality,density);
	   System.out.println(); 
	   
	   System.out.println("-----------------------------------------------------------------------------");
	 System.out.printf("%1s %5s %5s %5s %5s %5s %7s%10s" ,"ECONOMY", "CLARITY", "UNITY","COHESION","BALANCE","GROUPING","HOMOGENEITY","#ELEMENTS");
	 System.out.println(); 
	 System.out.println("-----------------------------------------------------------------------------");
	  
	 
	System.out.format(" %1s %7s %7s %7s %7s %7s %9s%10s",economy,clarity, unity,cohesion,balance,grouping,repartition,elements);
	       System.out.println();
	       System.out.println("----------------------------------");
	       System.out.printf("%1s", "• REMARKS");
			  System.out.println();
			  System.out.println("----------------------------------");
			  System.out.println("-----------------------------------------------------------------------------");
	    System.out.println("--Economy of the MUI :: you have  "+taille+"  components, with " + nature + " different types, and  "+occ+"  different sizes");
	    
	    
	    
	    if(taille>= 4 & taille<=17)
	    {System.out.println("        Your interface is considered minimalist");}
	    if(taille>= 18 & taille<=24)
	    {System.out.println("        Your interface is considered normal");}
	    if(taille>= 25 & taille<=31)
	    {System.out.println("        Your interface is considered normal but in risk to be overloaded");}
	    if(taille>= 32 & taille<=45)
	    {System.out.println("        Your interface is considered heavy ! ");}
	    
	    if(taille<=4 & taille <=14 & density>=0.6)
	    {  System.out.println("        Your interface is charged with different componenets sizes ! ");   }
	  System.out.println("--Regularity of the MUI :: number of rows= "+rows+" and number of columns= " +cols);
	  //System.out.println("      - There is "+distance+" different spaces between your widgets.");
	  //System.out.println("      - "+ distanceX+" differences in rows, and "+distanceY+" different distances in columns");
	  System.out.println("--Uniformity of the MUI :: Here is your widgets repartition on the MUI");
	  System.out.println("      - UL has "+(Sorting.ULnew)+" widget(s) / "+ "UR has "+ (Sorting.URnew)+" widget(s) /"+ "LL has "+ (Sorting.LLnew)+" widget(s) /"+ "LR has "+ (Sorting.LRnew)+" widget(s) ");
	  
	  if(btn>0)
      {
      	System.out.println("--Clarity of the MUI (button texts):: you have "+btn+ " button(s) without text(s) for " + button +" buttons");
      }
      if(item>0)
      {
      	System.out.println(" --Clarity of the MUI (menu items):: you have "+item+ " item(s) without title(s) for "+ items+ " items");
      }
      if(hint>0)
      {
      	System.out.println(" --Clarity of the MUI (EditText hints):: you have "+hint+ " EditText(s) without title(s) for "+ nbedit+ " items");
      }
      
      if(CL.value==0)
      {
      	System.out.println("You have no buttons, items nor EditText on your MUI !");
      }
       
      
      System.out.println("-----------------------------------------------------------------------------");
      System.out.printf("%10s", "• POSSIBLE DEFECTS");
	  System.out.println();

	  String overloaded="";
	   String difficult="";
	   String layout="";
	   String balanced="";
	   String cohesioned="";
	if(!rules.OM.equals("")){  overloaded="Detected";}
	if(!rules.DN.equals("")){  difficult="Detected";}
	if(!rules.ILW.equals("")){  layout="Detected";}
	if(!rules.IM.equals("")){  balanced="Detected";}
	if(!rules.ICM.equals("")){  cohesioned="Detected";}
	
	  System.out.println("-----------------------------------------------------------------------------");
	  System.out.println("----------------------------------------------");
	  System.out.printf("%1s %30s ", "Defect", "Status");
	  System.out.println();
	  System.out.println("----------------------------------------------");
	 System.out.printf("%1s %24s", "Overloaded MUI",overloaded);
	   
	   System.out.println(); 
	   
	   System.out.println("----------------------------------------------");
	   System.out.printf("%1s %24s", "Imbalanced MUI",balanced);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	   System.out.printf("%1s%22s", "InCohesion of MUI",cohesioned);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	   
	   System.out.printf("%1s %15s", "Incorrect layout of MUI",layout);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	   System.out.printf("%1s%19s", "Difficult navigation",difficult);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	  
	   
	   System.out.println(); 
	
	 
	 
	
	//Generate output file

	 
	// specify the path to the results out put file
		 PrintStream Output_file= new PrintStream (new File (data_File+"file.txt"));
	 
	 System.setOut(Output_file);
	 Output_file.print("----------------------------------");
	 Output_file.print("\n");
	 Output_file.print("Metrics");
	 Output_file.print("\n");
	 Output_file.print("----------------------------------");
	 Output_file.print("----------------------------------");
	 Output_file.print("\n");
	 Output_file.print(  "Uniformity = "+ uniformity +"\n"+" Complexity= " + complexity +"\n"+" Simplicity= "+simplicity + "\n"+" Sequence= " +sorting +"\n"+" Regularity= " +regularity +"\n"+" Integrality= "+integrality + "\n"+" Density= "+density +"\n"+" Economy= " +economy +"\n"+" Clarity= " + clarity +"\n"+" Unity= " + unity +"\n"+" Cohesion= " +cohesion +"\n"+" Balance=  "+balance +"\n"+ " Grouping= "+grouping+"\n"+" Homogeneity= "+repartition+"\n"+"Number of elements= "+elements);
	 Output_file.print("\n");
	 Output_file.print("----------------------------------");
	 Output_file.print("----------------------------------");
	 Output_file.print("\n");
	 Output_file.print("Remarks");
	 Output_file.print("\n");
	 Output_file.print("----------------------------------");
	 Output_file.print("----------------------------------");
	 Output_file.print("\n");
	 Output_file.print("--Economy of the MUI :: you have  "+taille+"  components, with  "+occ+"  different types");
	 Output_file.print("\n");
	 if(taille>= 4 & taille<=9)
	    {System.out.println("        Your interface is considered minimalist");}
	    if(taille>= 10 & taille<=14)
	    {System.out.println("        Your interface is considered normal");}
	    if(taille>= 13 & taille<=14)
	    {System.out.println("        Your interface is considered normal but in risk to be overloaded");}
	    if(taille>= 15 & taille<=20)
	    {System.out.println("        Your interface is considered heavy ! ");}
	    Output_file.print("--Regularity of the MUI :: number of rows= "+rows+" and number of columns= " +cols);
	    Output_file.print("\n");
	    //Output_file.print("      - There is "+distance+" different spaces between your widgets.");
	    //Output_file.print("\n");
	    //Output_file.print("      - "+ distanceX+" differences in rows, and "+distanceY+" different distances in columns");
	    //Output_file.print("\n");
	    Output_file.print("--Uniformity of the MUI :: Here is your widgets repartition on the MUI");
	    Output_file.print("\n");
	    Output_file.println("      - UL has "+(Sorting.ULnew)+" widget(s) / "+ "UR has "+ (Sorting.URnew)+" widget(s) /"+ "LL has "+ (Sorting.LLnew)+" widget(s) /"+ "LR has "+ (Sorting.LRnew)+" widget(s) ");
	    Output_file.print("\n");
	  if(btn>0)
     {
		  Output_file.print("--Clarity of the MUI (button texts):: you have "+btn+ " button(s) without text(s) for " + button +" buttons");
		  Output_file.print("\n");
     }
     if(item>0)
     {
    	 Output_file.print(" --Clarity of the MUI (menu items):: you have "+item+ " item(s) without title(s) for "+ items+ " items");
    	 Output_file.print("\n");
     }
	 
     Output_file.print("\n");
     Output_file.print("----------------------------------");
     Output_file.print("----------------------------------");
     Output_file.print("\n");
     Output_file.print("Defects");
     Output_file.print("\n");
     Output_file.print("----------------------------------");
     Output_file.print("----------------------------------");
     Output_file.print("\n");
	
	 System.out.println("-----------------------------------------------------------------------------");
	  System.out.println("----------------------------------------------");
	  System.out.printf("%1s %30s ", "Defect", "Status");
	  System.out.println();
	  System.out.println("----------------------------------------------");
	 System.out.printf("%1s %24s", "Overloaded MUI",overloaded);
	   
	   System.out.println(); 
	   
	   System.out.println("----------------------------------------------");
	   System.out.printf("%1s %24s", "Imbalanced MUI",balanced);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	   System.out.printf("%1s%22s", "InCohesion of MUI",cohesioned);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	   
	   System.out.printf("%1s %15s", "Incorrect layout of MUI",layout);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	   System.out.printf("%1s%19s", "Difficult navigation",difficult);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	  

	   System.out.println(); 
	 
	 
	}
	

}
