package per_App;

import java.io.FileInputStream;

import java.io.IOException;
import java.io.InputStream;


import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * @author bessghaiernarjess
 * 
 */

public class co_occurr_per_app {

	public static final String My_File = "/Users/bessghaiernarjess/Documents/Ph.D_Thesis/main/step1/data-sets/occurring_per_app_new.xls";
	
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
 int ILW_OM=0;
 int ILW_DN=0;
 int ILW_ICM=0;
 int ILW_IM=0;
 int OM_DN=0;
 int OM_ICM=0;
 int OM_IM=0;
 int DN_ICM=0;
 int DN_IM=0;
 int ICM_IM=0;

String OM_index="";
String ILW_index="";
String IM_index="";
String ICM_index="";
String DN_index="";

String[] splitArrayOM = null;
String[] splitArrayILW = null;
String[] splitArrayIM = null;
String[] splitArrayICM = null;
String[] splitArrayDN = null;



		InputStream input = new FileInputStream(My_File);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
		 //row number
		 int rowTotal = sheet.getLastRowNum();
	
       if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
           rowTotal++;
       }
		
       //System.out.println(rowTotal);
		
		//parse each row
       for ( int r=0;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=0;c<noOfColumns; c++)
	    	        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			//System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 
			 String text= cell.getStringCellValue();
			 //System.out.println("text="+text);
			 if (text.equals("OM"))
			 {
				 //System.out.println("oui");
				OM_index=OM_index+(r+1)+",";
				// System.out.println("OM_index"+OM_index); 
			 }
			 else if (text.equals("ILW"))
			 {
				 ILW_index=ILW_index+(r+1)+",";
				// System.out.println("ILW_index"+ILW_index); 
				 
			 }
			 else if (text.equals("IM"))
			 {
				 IM_index=IM_index+(r+1)+",";
				 //System.out.println("IM_index"+IM_index); 
				
			 }
			 else if (text.equals("DN"))
			 {
				 DN_index=DN_index+(r+1)+",";
				// System.out.println("DN_index"+DN_index); 
				
			 }
			 else 
			 {
				 ICM_index=ICM_index+(r+1)+",";
				// System.out.println("ICM_index"+ICM_index); 
				 
			 }	 
       }
       }
       

       System.out.println("OM existe dans les rows::"+OM_index);
       System.out.println("ILW existe dans les rows::"+ILW_index);
       System.out.println("IM existe dans les rows::"+IM_index);
       System.out.println("ICM existe dans les rows::"+ICM_index);
       System.out.println("DN existe dans les rows::"+DN_index);
       
       
       
       
     //#####################################
     //#####################################
       //comparaison des couples  de defauts
     //#####################################
     //#####################################
       
       /*
        * ########## ILW-OM
       */
       

    	   splitArrayOM = OM_index.split(",");
    	 
    	   for(int i = 0; i< splitArrayOM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayOM[i]+"]");
    		 
    		  }
    	   splitArrayILW = ILW_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayILW.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayILW[i]+"]");
    		 
    		  }
       
    	   if(splitArrayOM.length>splitArrayILW.length){
    		  // System.out.println( "oui1");
    	   for (int i=0;i<splitArrayOM.length;i++)
    		   
    	   {
    		   for (int j=0;j<splitArrayILW.length;j++)
        		   
        	   {
        		   if (splitArrayOM[i]==splitArrayILW[j])
        		   {
        			   ILW_OM++;
        		   }
        	   } 
    		   
    	   }}
    	   
    	   if(splitArrayILW.length>splitArrayOM.length){
    		  // System.out.println( "oui2");
        	   for (int i=0;i<splitArrayILW.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayOM.length;j++)
            		   
            	   {
            		   if (splitArrayILW[i].equals(splitArrayOM[j]))
            		   {
            			   ILW_OM++;
            		   }
            	   } 
        		   
        	   }}
       
    	   if(splitArrayILW.length==splitArrayOM.length){
     		  // System.out.println( "oui2");
         	   for (int i=0;i<splitArrayILW.length;i++)
         		   
         	   {
         		   for (int j=0;j<splitArrayOM.length;j++)
             		   
             	   {
             		   if (splitArrayILW[i].equals(splitArrayOM[j]))
             		   {
             			   ILW_OM++;
             		   }
             	   } 
         		   
         	   }}
       /*
        * ########## ILW-DN
       */
       
    	   
    	   
    	   splitArrayILW = ILW_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayILW.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayOM[i]+"]");
    		 
    		  }
    	   splitArrayDN = DN_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayDN.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayILW[i]+"]");
    		 
    		  }
       
    	   if(splitArrayILW.length>splitArrayDN.length){
    		//   System.out.println( "oui1");
    	   for (int i=0;i<splitArrayILW.length;i++)
    		   
    	   {
    		   for (int j=0;j<splitArrayDN.length;j++)
        		   
        	   {
        		   if (splitArrayILW[i].equals(splitArrayDN[j]))
        		   {
        			   ILW_DN++;
        		   }
        	   } 
    		   
    	   }}
    	   
    	   if(splitArrayDN.length>splitArrayILW.length){
    		  // System.out.println( "oui2");
        	   for (int i=0;i<splitArrayDN.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayILW.length;j++)
            		   
            	   {
            		   if (splitArrayDN[i].equals(splitArrayILW[j]))
            		   {
            			   ILW_DN++;
            		   }
            	   } 
        		   
        	   }}
       
    	   if(splitArrayILW.length==splitArrayOM.length){
     		  // System.out.println( "oui2");
         	   for (int i=0;i<splitArrayILW.length;i++)
         		   
         	   {
         		   for (int j=0;j<splitArrayOM.length;j++)
             		   
             	   {
             		   if (splitArrayILW[i].equals(splitArrayOM[j]))
             		   {
             			   ILW_OM++;
             		   }
             	   } 
         		   
         	   }}
    	   
    	   
       
       /*
        * ########## ILW-ICM
       */
       
    	   
    	   
    	   splitArrayILW = ILW_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayILW.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayOM[i]+"]");
    		 
    		  }
    	   splitArrayICM = ICM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayICM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayILW[i]+"]");
    		 
    		  }
       
    	   if(splitArrayILW.length>splitArrayICM.length){
    		  // System.out.println( "oui1");
    	   for (int i=0;i<splitArrayILW.length;i++)
    		   
    	   {
    		   for (int j=0;j<splitArrayICM.length;j++)
        		   
        	   {
        		   if (splitArrayILW[i].equals(splitArrayICM[j]))
        		   {
        			   ILW_ICM++;
        		   }
        	   } 
    		   
    	   }}
    	   
    	   if(splitArrayICM.length>splitArrayILW.length){
    		  // System.out.println( "oui2");
        	   for (int i=0;i<splitArrayICM.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayILW.length;j++)
            		   
            	   {
            		   if (splitArrayICM[i].equals(splitArrayILW[j]))
            		   {
            			   ILW_ICM++;
            		   }
            	   } 
        		   
        	   }}
       
    	   
    	   if(splitArrayICM.length==splitArrayILW.length){
     		  // System.out.println( "oui2");
         	   for (int i=0;i<splitArrayICM.length;i++)
         		   
         	   {
         		   for (int j=0;j<splitArrayILW.length;j++)
             		   
             	   {
             		   if (splitArrayICM[i].equals(splitArrayILW[j]))
             		   {
             			   ILW_ICM++;
             		   }
             	   } 
         		   
         	   }}
    	   
    	   
       
       /*
        * ########## ILW-IM
       */
       
       
    	   
    	   
    	   splitArrayILW = ILW_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayILW.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayOM[i]+"]");
    		 
    		  }
    	   splitArrayIM = IM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayIM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayILW[i]+"]");
    		 
    		  }
       
    	   if(splitArrayILW.length>splitArrayIM.length){
    		   //System.out.println( "oui1");
    	   for (int i=0;i<splitArrayILW.length;i++)
    		   
    	   {
    		   for (int j=0;j<splitArrayIM.length;j++)
        		   
        	   {
        		   if (splitArrayILW[i].equals(splitArrayIM[j]))
        		   {
        			   ILW_IM++;
        		   }
        	   } 
    		   
    	   }}
    	   
    	   if(splitArrayIM.length>splitArrayILW.length){
    		  // System.out.println( "oui2");
        	   for (int i=0;i<splitArrayIM.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayILW.length;j++)
            		   
            	   {
            		   if (splitArrayIM[i].equals(splitArrayILW[j]))
            		   {
            			   ILW_IM++;
            		   }
            	   } 
        		   
        	   }}
       
    	   
    	   if(splitArrayIM.length==splitArrayILW.length){
     		  // System.out.println( "oui2");
         	   for (int i=0;i<splitArrayIM.length;i++)
         		   
         	   {
         		   for (int j=0;j<splitArrayILW.length;j++)
             		   
             	   {
             		   if (splitArrayIM[i].equals(splitArrayILW[j]))
             		   {
             			   ILW_IM++;
             		   }
             	   } 
         		   
         	   }}
    	   
    	   
    	   
    	   
    	   
    	   
    	   
       /*
        * ########## OM-DN
       */
       
       
    	   
    	   splitArrayOM = OM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayOM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayOM[i]+"]");
    		 
    		  }
    	   splitArrayDN = DN_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayDN.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayILW[i]+"]");
    		 
    		  }
       
    	   if(splitArrayOM.length>splitArrayDN.length){
    		 //  System.out.println( "oui1");
    	   for (int i=0;i<splitArrayOM.length;i++)
    		   
    	   {
    		   for (int j=0;j<splitArrayDN.length;j++)
        		   
        	   {
        		   if (splitArrayOM[i].equals(splitArrayDN[j]))
        		   {
        			   OM_DN++;
        		   }
        	   } 
    		   
    	   }}
    	   
    	   if(splitArrayDN.length>splitArrayOM.length){
    		  // System.out.println( "oui2");
        	   for (int i=0;i<splitArrayDN.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayOM.length;j++)
            		   
            	   {
            		   if (splitArrayDN[i].equals(splitArrayOM[j]))
            		   {
            			   OM_DN++;
            		   }
            	   } 
        		   
        	   }}
       
    	   if(splitArrayDN.length==splitArrayOM.length){
     		  // System.out.println( "oui2");
         	   for (int i=0;i<splitArrayDN.length;i++)
         		   
         	   {
         		   for (int j=0;j<splitArrayOM.length;j++)
             		   
             	   {
             		   if (splitArrayDN[i].equals(splitArrayOM[j]))
             		   {
             			   OM_DN++;
             		   }
             	   } 
         		   
         	   }}
        
    	   
    	   
       
       /*
        * ########## OM-ICM
       */
       
    	   
    	   
    	   splitArrayOM = OM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayOM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayOM[i]+"]");
    		 
    		  }
    	   splitArrayICM = ICM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayICM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayILW[i]+"]");
    		 
    		  }
       
    	   if(splitArrayOM.length>splitArrayICM.length){
    		  // System.out.println( "oui1");
    	   for (int i=0;i<splitArrayOM.length;i++)
    		   
    	   {
    		   for (int j=0;j<splitArrayICM.length;j++)
        		   
        	   {
        		   if (splitArrayOM[i].equals(splitArrayICM[j]))
        		   {
        			   OM_ICM++;
        		   }
        	   } 
    		   
    	   }}
    	   
    	   if(splitArrayICM.length>splitArrayOM.length){
    		 //  System.out.println( "oui2");
        	   for (int i=0;i<splitArrayICM.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayOM.length;j++)
            		   
            	   {
            		   if (splitArrayICM[i].equals(splitArrayOM[j]))
            		   {
            			   OM_ICM++;
            		   }
            	   } 
        		   
        	   }}
       
    	   if(splitArrayICM.length==splitArrayOM.length){
      		 //  System.out.println( "oui2");
          	   for (int i=0;i<splitArrayICM.length;i++)
          		   
          	   {
          		   for (int j=0;j<splitArrayOM.length;j++)
              		   
              	   {
              		   if (splitArrayICM[i].equals(splitArrayOM[j]))
              		   {
              			   OM_ICM++;
              		   }
              	   } 
          		   
          	   }}
    	   
    	   
    	   
    	   
       
       /*
        * ########## OM-IM
       */
       
       
    	   splitArrayOM = OM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayOM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayOM[i]+"]");
    		 
    		  }
    	   splitArrayIM = IM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayIM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayILW[i]+"]");
    		 
    		  }
       
    	   if(splitArrayOM.length>splitArrayIM.length){
    		  // System.out.println( "oui1");
    	   for (int i=0;i<splitArrayOM.length;i++)
    		   
    	   {
    		   for (int j=0;j<splitArrayIM.length;j++)
        		   
        	   {
        		   if (splitArrayOM[i].equals(splitArrayIM[j]))
        		   {
        			   OM_IM++;
        		   }
        	   } 
    		   
    	   }}
    	   
    	   if(splitArrayIM.length>splitArrayOM.length){
    		  // System.out.println( "oui2");
        	   for (int i=0;i<splitArrayIM.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayOM.length;j++)
            		   
            	   {
            		   if (splitArrayIM[i].equals(splitArrayOM[j]))
            		   {
            			   OM_IM++;
            		   }
            	   } 
        		   
        	   }}
       
    	   if(splitArrayIM.length==splitArrayOM.length){
     		  // System.out.println( "oui2");
         	   for (int i=0;i<splitArrayIM.length;i++)
         		   
         	   {
         		   for (int j=0;j<splitArrayOM.length;j++)
             		   
             	   {
             		   if (splitArrayIM[i].equals(splitArrayOM[j]))
             		   {
             			   OM_IM++;
             		   }
             	   } 
         		   
         	   }}
    	   
    	   
    	   
       /*
        * ########## DN-ICM
       */
       
       
    	   splitArrayDN = DN_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayDN.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayOM[i]+"]");
    		 
    		  }
    	   splitArrayICM = ICM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayICM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayILW[i]+"]");
    		 
    		  }
       
    	   if(splitArrayDN.length>splitArrayICM.length){
    		//   System.out.println( "oui1");
    	   for (int i=0;i<splitArrayDN.length;i++)
    		   
    	   {
    		   for (int j=0;j<splitArrayICM.length;j++)
        		   
        	   {
        		   if (splitArrayDN[i].equals(splitArrayICM[j]))
        		   {
        			   DN_ICM++;
        		   }
        	   } 
    		   
    	   }}
    	   
    	   if(splitArrayICM.length>splitArrayDN.length){
    		 //  System.out.println( "oui2");
        	   for (int i=0;i<splitArrayICM.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayDN.length;j++)
            		   
            	   {
            		   if (splitArrayICM[i].equals(splitArrayDN[j]))
            		   {
            			   DN_ICM++;
            			  
            		   }
            	   } 
        		   
        	   }}
       
    	   if(splitArrayICM.length==splitArrayDN.length){
      		 //  System.out.println( "oui2");
          	   for (int i=0;i<splitArrayICM.length;i++)
          		   
          	   {
          		   for (int j=0;j<splitArrayDN.length;j++)
              		   
              	   {
              		   if (splitArrayICM[i].equals(splitArrayDN[j]))
              		   {
              			   DN_ICM++;
              			  
              		   }
              	   } 
          		   
          	   }}
    	   
       /*
        * ########## DN-IM
       */
       
    	   
    	   splitArrayDN = DN_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayDN.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayOM[i]+"]");
    		 
    		  }
    	   splitArrayIM = IM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayIM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayILW[i]+"]");
    		 
    		  }
       
    	   if(splitArrayDN.length>splitArrayIM.length){
    		 // System.out.println( "oui1");
    	   for (int i=0;i<splitArrayDN.length;i++)
    		   
    	   {
    		   for (int j=0;j<splitArrayIM.length;j++)
        		   
        	   {
        		   if (splitArrayDN[i].equals(splitArrayIM[j]))
        		   {
        			   DN_IM++;
        		   }
        	   } 
    		   
    	   }}
    	   
    	   if(splitArrayIM.length>splitArrayDN.length){
    		 //  System.out.println( "oui2");
        	   for (int i=0;i<splitArrayIM.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayDN.length;j++)
            		   
            	   {
            		   if (splitArrayIM[i].equals(splitArrayDN[j]))
            		   {
            			   DN_IM++;
            		   }
            	   } 
        		   
        	   }}
       
    	   
    	   if(splitArrayIM.length==splitArrayDN.length){
    		   //System.out.println( "oui3");
        	   for (int i=0;i<splitArrayIM.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayDN.length;j++)
            		   
            	   {
            		   if (splitArrayIM[i].equals(splitArrayDN[j]))
            		   {
            			   DN_IM++;
            		   }
            	   } 
        		   
        	   }}
    	   
       
       /*
        * ########## ICM-IM
       */
       
       
    	   splitArrayICM = ICM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayICM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayOM[i]+"]");
    		 
    		  }
    	   splitArrayIM = IM_index.split(",");
      	 
    	   for(int i = 0; i< splitArrayIM.length;i++){
    		   // On affiche chaque élément du tableau
    		// System.out.println( i + "=[" + splitArrayILW[i]+"]");
    		 
    		  }
       
    	   if(splitArrayICM.length>splitArrayIM.length){
    		 //  System.out.println( "oui1");
    	   for (int i=0;i<splitArrayICM.length;i++)
    		   
    	   {
    		   for (int j=0;j<splitArrayIM.length;j++)
        		   
        	   {
        		   if (splitArrayICM[i].equals(splitArrayIM[j]))
        		   {
        			   ICM_IM++;
        		   }
        	   } 
    		   
    	   }}
    	   
    	   if(splitArrayIM.length>splitArrayICM.length){
    		 //  System.out.println( "oui2");
        	   for (int i=0;i<splitArrayIM.length;i++)
        		   
        	   {
        		   for (int j=0;j<splitArrayICM.length;j++)
            		   
            	   {
            		   if (splitArrayIM[i].equals(splitArrayICM[j]))
            		   {
            			   ICM_IM++;
            		   }
            	   } 
        		   
        	   }}
    	   if(splitArrayIM.length==splitArrayICM.length){
      		 //  System.out.println( "oui2");
          	   for (int i=0;i<splitArrayIM.length;i++)
          		   
          	   {
          		   for (int j=0;j<splitArrayICM.length;j++)
              		   
              	   {
              		   if (splitArrayIM[i].equals(splitArrayICM[j]))
              		   {
              			   ICM_IM++;
              		   }
              	   } 
          		   
          	   }}
    	   
    	   
    	   
			 System.out.println("(ILW_OM)="+ILW_OM +"  percentage= "+ ((ILW_OM*100)/rowTotal)+"%");
				
			 System.out.println("(ILW_DN)="+ILW_DN+"  percentage= "+ ((ILW_DN*100)/rowTotal)+"%");
		
			 System.out.println("(ILW_ICM)="+ILW_ICM+"  percentage= "+ ((ILW_ICM*100)/rowTotal)+"%");
		 
			 System.out.println("(ILW_IM)="+ILW_IM+"  percentage= "+ ((ILW_IM*100)/rowTotal)+"%");
		
			 System.out.println("(OM_DN)="+OM_DN+"  percentage= "+ ((OM_DN*100)/rowTotal)+"%");
		
			 System.out.println("(OM_ICM)="+OM_ICM+"  percentage= "+ ((OM_ICM*100)/rowTotal)+"%");
		 
			 System.out.println("(OM_IM)="+OM_IM+"  percentage= "+ ((OM_IM*100)/rowTotal)+"%");
		
			 System.out.println("(DN_ICM)="+DN_ICM+"  percentage= "+ ((DN_ICM*100)/rowTotal)+"%");
		
			 System.out.println("(DN_IM)="+DN_IM+"  percentage= "+ ((DN_IM*100)/rowTotal)+"%");
		
			 System.out.println("(ICM_IM)="+ICM_IM+"  percentage= "+ ((ICM_IM*100)/rowTotal)+"%");
		
       
       
       
		
	}
	
	}
