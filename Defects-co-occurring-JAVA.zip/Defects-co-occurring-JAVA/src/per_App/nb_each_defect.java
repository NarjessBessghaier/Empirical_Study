package per_App;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class nb_each_defect {
	public static final String My_File = "/Users/bessghaiernarjess/Documents/Ph.D_Thesis/main/step1/data-sets/occurring_per_app.xls";
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int OM_index=0;
		int ILW_index=0;
		int IM_index=0;
		int ICM_index=0;
		int DN_index=0;
		
		InputStream input = new FileInputStream(My_File);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
		 //row number
		 int rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
		
      //System.out.println(rowTotal);
		
		//parse each row
      for ( int r=0;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=0;c<noOfColumns; c++)
	    	        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 
			 String text= cell.getStringCellValue();
			 //System.out.println("text="+text);
			 if (text.equals("OM"))
			 {
				 //System.out.println("oui");
				OM_index++;;
				// System.out.println("OM_index"+OM_index); 
			 }
			 else if (text.equals("ILW"))
			 {
				 ILW_index++;
				// System.out.println("ILW_index"+ILW_index); 
				 
			 }
			 else if (text.equals("IM"))
			 {
				 IM_index++;
				 //System.out.println("IM_index"+IM_index); 
				
			 }
			 else if (text.equals("DN"))
			 {
				 DN_index++;
				// System.out.println("DN_index"+DN_index); 
				
			 }
			 else 
			 {
				 ICM_index++;
				// System.out.println("ICM_index"+ICM_index); 
				 
			 }	 
      }
      }
      

      System.out.println("nb occurrence de OM=  "+OM_index);
      System.out.println("nb occurrence de ILW=  "+ILW_index);
      System.out.println("nb occurrence de IM=  "+IM_index);
      System.out.println("nb occurrence de ICM=  "+ICM_index);
      System.out.println("nb occurrence de DN=  "+DN_index);
      
      
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
