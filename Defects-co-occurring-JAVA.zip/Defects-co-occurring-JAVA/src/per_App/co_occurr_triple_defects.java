package per_App;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
public class co_occurr_triple_defects {
	public static final String My_File = "/Users/bessghaiernarjess/Documents/Ph.D_Thesis/main/step1/data-sets/occurring_per_app_new.xls";
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		
int three_defect = 0;
		
		InputStream input = new FileInputStream(My_File);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
		 //row number
		 int rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
		
      //System.out.println(rowTotal);
		
		//parse each row
      for ( int r=0;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 if (noOfColumns==3)
			 {
				 
				 three_defect++;
			 }
      }
		
		
		
		
		
		
		
		
		
		System.out.println("Interfaces with three defect equal to=" + three_defect+"percentage="+ ((three_defect*100)/rowTotal)+"%");
		
		
		
		
		
		
		
	}

}
